function startHalobot() {
  alert("Halobot is waking up… 🤖✨");
}
